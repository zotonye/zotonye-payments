# Zotonye Payments — Cloudflare Pages starter

This package contains a minimalist payment page and server-side Cloudflare Pages Functions for Paystack. **It is not live until deployed and configured.**

## Included
- General Paystack Checkout for NGN payments.
- Hosted Paystack Direct Debit mandate setup for new customers.
- Existing active mandate lookup after email OTP verification.
- Existing mandate charge only after email verification and explicit confirmation.
- Transaction reference verification. Paystack secret key is server-side only.

## Deployment and configuration
1. Create a Cloudflare Pages project named `zotonye-payments`. Because this project uses Pages Functions, deploy through Git integration or Wrangler; a static drag-and-drop upload alone is not sufficient for the backend.
2. Create a Cloudflare D1 database named `zotonye-payments` and run `schema.sql` against it.
3. Replace `REPLACE_WITH_CLOUDFLARE_D1_DATABASE_ID` in `wrangler.toml` with the actual D1 database ID. Bind it to the Pages project as `DB`.
4. Add these server-side secrets/variables in Cloudflare Pages settings: `PAYSTACK_SECRET_KEY` (correct Paystack integration's secret key), `RESEND_API_KEY`, `RESEND_FROM` (a sender address verified with Resend), and `OTP_PEPPER` (a long random secret). Never put the Paystack secret key in `index.html`.
5. Deploy/redeploy the project. Add `pay.zotonye.com` under Cloudflare Pages > Custom domains and follow the DNS instructions shown there. Do not change the existing `zotonye.com` site.
6. Test in Paystack test mode first. Test normal checkout, new mandate authorization, email OTP, active mandate charging, failed charges, and transaction verification. Switch to live keys only after tests pass.

## Important
- Direct Debit is for eligible Nigeria-based businesses and supported banks. New mandates are not usable until Paystack confirms they are active.
- The existing-mandate flow requires email OTP and a customer confirmation for each payment. Do not remove these safeguards.
- Payment status `processing` is not success. Verify final status in Paystack before treating a payment as paid.
- Configure webhooks for production reconciliation; the page's return URL check is not a replacement for webhook verification.
- No API keys, account credentials, domain changes, or deployment have been performed by this package.
